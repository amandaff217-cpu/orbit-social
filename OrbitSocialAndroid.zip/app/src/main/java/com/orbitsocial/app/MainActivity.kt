package com.orbitsocial.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.FieldValue

private val Night = Color(0xFF090B0C)
private val Panel = Color(0xFF171C1D)
private val Lime = Color(0xFFD8FF49)
private val Sky = Color(0xFFB8EFFF)
private val Muted = Color(0xFF9AA3A5)

data class SocialPost(
    val id: String = "",
    val author: String = "Orbit user",
    val text: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val likes: Long = 0
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { OrbitSocialApp() }
    }
}

@Composable
fun OrbitSocialApp() {
    var tab by remember { mutableStateOf("Início") }
    var posts by remember { mutableStateOf(listOf(
        SocialPost(id = "sample1", author = "orbit.community", text = "Um novo dia, novas histórias. Encontre beleza nos pequenos momentos.", likes = 21)
    )) }
    var composeOpen by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("Seu perfil") }
    var status by remember { mutableStateOf("Modo demonstração — conecte o Firebase para publicar online.") }

    val auth = remember { runCatching { FirebaseAuth.getInstance() }.getOrNull() }
    val db = remember { runCatching { FirebaseFirestore.getInstance() }.getOrNull() }

    DisposableEffect(db) {
        var registration: ListenerRegistration? = null
        if (db != null) {
            registration = db.collection("posts").orderBy("createdAt", Query.Direction.DESCENDING)
                .limit(50).addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        status = "Não foi possível carregar o feed. Verifique a configuração do Firebase."
                    } else if (snapshot != null && !snapshot.isEmpty) {
                        posts = snapshot.documents.map { doc ->
                            SocialPost(
                                id = doc.id,
                                author = doc.getString("author") ?: "Orbit user",
                                text = doc.getString("text") ?: "",
                                createdAt = doc.getLong("createdAt") ?: 0L,
                                likes = doc.getLong("likes") ?: 0L
                            )
                        }
                        status = "Feed conectado"
                    }
                }
        }
        onDispose { registration?.remove() }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Night, surface = Panel, primary = Lime,
        onPrimary = Night, onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Night,
            topBar = {
                Row(
                    Modifier.fillMaxWidth().background(Night).padding(horizontal = 20.dp, vertical = 17.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text("Orbit", fontSize = 29.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("•", fontSize = 25.sp, color = Lime)
                        Text(" Social", fontSize = 13.sp, color = Muted)
                    }
                    IconButton(onClick = { tab = "Mensagens" }) {
                        Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Mensagens", tint = Color.White)
                    }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    val destinations = listOf(
                        "Início" to Icons.Default.Home,
                        "Explorar" to Icons.Default.Explore,
                        "Criar" to Icons.Default.AddCircle,
                        "Favoritos" to Icons.Default.FavoriteBorder,
                        "Perfil" to Icons.Default.Person
                    )
                    destinations.forEach { (label, icon) ->
                        NavigationBarItem(
                            selected = tab == label,
                            onClick = { if (label == "Criar") composeOpen = true else tab = label },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Lime, selectedTextColor = Lime,
                                indicatorColor = Color(0xFF303A28),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Night)) {
                when (tab) {
                    "Início" -> FeedScreen(posts, status, onPro = { tab = "Orbit Pro" }, onLike = { post ->
                        if (db != null && post.id != "sample1") {
                            db.collection("posts").document(post.id)
                                .update("likes", FieldValue.increment(1))
                        } else {
                            posts = posts.map { if (it.id == post.id) it.copy(likes = it.likes + 1) else it }
                        }
                    })
                    "Explorar" -> ExploreScreen()
                    "Favoritos" -> SimpleScreen("Seus favoritos", "As publicações que você curtir aparecerão aqui.")
                    "Perfil" -> ProfileScreen(displayName) { name -> displayName = name }
                    "Mensagens" -> SimpleScreen("Mensagens", "A estrutura de conversas está preparada. O chat em tempo real será conectado na próxima etapa.")
                    "Orbit Pro" -> ProScreen { tab = "Início" }
                    else -> FeedScreen(posts, status, onPro = { tab = "Orbit Pro" }, onLike = {})
                }
            }
        }

        if (composeOpen) {
            AlertDialog(
                onDismissRequest = { composeOpen = false },
                containerColor = Panel,
                title = { Text("Nova publicação", color = Color.White) },
                text = {
                    OutlinedTextField(
                        value = draft, onValueChange = { draft = it },
                        placeholder = { Text("O que você gostaria de compartilhar?") },
                        minLines = 3, colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Lime, unfocusedBorderColor = Muted
                        )
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        val text = draft.trim()
                        if (text.isNotEmpty()) {
                            val user = auth?.currentUser
                            if (db != null && user != null) {
                                db.collection("posts").add(mapOf(
                                    "uid" to user.uid, "author" to (user.displayName ?: displayName),
                                    "text" to text, "createdAt" to System.currentTimeMillis(), "likes" to 0
                                ))
                                status = "Publicação enviada"
                            } else {
                                posts = listOf(SocialPost(id = System.nanoTime().toString(), author = displayName, text = text)) + posts
                                status = "Publicação local. Entre e conecte o Firebase para compartilhar online."
                            }
                            draft = ""
                            composeOpen = false
                            tab = "Início"
                        }
                    }) { Text("Publicar", color = Lime) }
                },
                dismissButton = { TextButton(onClick = { composeOpen = false }) { Text("Cancelar", color = Muted) } }
            )
        }
    }
}

@Composable
fun FeedScreen(posts: List<SocialPost>, status: String, onPro: () -> Unit, onLike: (SocialPost) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        item {
            Row(
                Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Lime, Sky)), RoundedCornerShape(18.dp))
                    .clickable { onPro() }.padding(17.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Atualize para Orbit Pro 🚀", color = Night, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("Mais possibilidades para você", color = Night, fontSize = 13.sp)
                }
                Text("→", color = Night, fontSize = 27.sp)
            }
            Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
        }
        items(posts, key = { it.id }) { post ->
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 5.dp)) {
                    Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Lime, Sky)), CircleShape), contentAlignment = Alignment.Center) {
                        Text(post.author.take(1).uppercase(), color = Night, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.padding(start = 10.dp)) {
                        Text(post.author, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("Orbit Social", color = Muted, fontSize = 11.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.MoreHoriz, contentDescription = null, tint = Muted)
                }
                Box(
                    Modifier.fillMaxWidth().heightIn(min = 190.dp).background(
                        Brush.linearGradient(listOf(Color(0xFFB8D1C5), Color(0xFF536E65), Color(0xFF263B37))),
                        RoundedCornerShape(14.dp)
                    ).padding(22.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(post.text, color = Color(0xFF101817), fontSize = 19.sp, fontWeight = FontWeight.Medium)
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                    TextButton(onClick = { onLike(post) }) {
                        Icon(Icons.Default.FavoriteBorder, contentDescription = "Curtir", tint = Lime)
                        Text(" ${post.likes}", color = Color.White)
                    }
                    TextButton(onClick = {}) {
                        Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Comentar", tint = Color.White)
                        Text("  Comentar", color = Color.White)
                    }
                    TextButton(onClick = {}) {
                        Icon(Icons.Default.Send, contentDescription = "Compartilhar", tint = Color.White)
                    }
                }
                Text("${post.author}  ${post.text}", color = Color.White, fontSize = 13.sp)
                HorizontalDivider(Modifier.padding(top = 12.dp), color = Color(0xFF252B2C))
            }
        }
    }
}

@Composable
fun ExploreScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Explorar", fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text("Descubra novas pessoas e ideias.", color = Muted, modifier = Modifier.padding(top = 5.dp, bottom = 20.dp))
        OutlinedTextField(value = "", onValueChange = {}, enabled = false, placeholder = { Text("Buscar pessoas e publicações") }, modifier = Modifier.fillMaxWidth())
        listOf("Fotografia 📸", "Viagens 🌎", "Arte 🎨", "Ideias 💡").forEach {
            Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Text(it, modifier = Modifier.padding(18.dp), fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun ProfileScreen(initialName: String, onSave: (String) -> Unit) {
    var name by remember(initialName) { mutableStateOf(initialName) }
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(22.dp))
        Box(Modifier.size(90.dp).background(Brush.linearGradient(listOf(Lime, Sky)), CircleShape), contentAlignment = Alignment.Center) {
            Text("EU", color = Night, fontWeight = FontWeight.Black, fontSize = 26.sp)
        }
        Text(initialName, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
        Text("@seuusuario", color = Muted, fontSize = 13.sp)
        Text("Compartilhando momentos pelo Orbit. ✨", modifier = Modifier.padding(top = 12.dp))
        Row(Modifier.fillMaxWidth().padding(vertical = 28.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat("0", "Publicações"); Stat("0", "Seguidores"); Stat("0", "Seguindo")
        }
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nome de exibição") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { onSave(name) }, colors = ButtonDefaults.buttonColors(containerColor = Lime, contentColor = Night), modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
            Text("Salvar perfil")
        }
    }
}
@Composable fun Stat(number: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(number, fontWeight = FontWeight.Bold); Text(label, color = Muted, fontSize = 11.sp) }
}
@Composable fun SimpleScreen(title: String, body: String) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        Text(title, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        Text(body, color = Muted, modifier = Modifier.padding(top = 10.dp))
    }
}
@Composable fun ProScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        TextButton(onClick = onBack) { Text("← Voltar", color = Muted) }
        Box(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Lime, Sky)), RoundedCornerShape(22.dp)).padding(22.dp)) {
            Column {
                Text("✦", fontSize = 35.sp, color = Night)
                Text("Orbit Pro", fontSize = 31.sp, fontWeight = FontWeight.Black, color = Night)
                Text("Mais possibilidades para sua experiência social.", color = Night)
            }
        }
        listOf("✓  Personalização avançada", "✓  Mais ferramentas de criação", "✓  Experiência exclusiva").forEach {
            Text(it, modifier = Modifier.padding(vertical = 13.dp), fontWeight = FontWeight.SemiBold)
        }
        Text("A tela PRO é demonstrativa. Para cobrar assinaturas, configure o Google Play Billing e a validação de compras no servidor.", color = Muted, fontSize = 12.sp)
    }
}
