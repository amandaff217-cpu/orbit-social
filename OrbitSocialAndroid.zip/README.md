# Orbit Social — Android starter

Projeto inicial Android nativo em Kotlin + Jetpack Compose, com visual escuro e acentos verde-limão/azul.

## O que já existe
- Feed de publicações e navegação inferior
- Tela Explorar, Favoritos, Perfil, Mensagens (placeholder) e Orbit Pro (demonstrativa)
- Criar publicação localmente
- Integração inicial opcional com Firebase Firestore para carregar/publicar posts quando o usuário estiver autenticado
- Curtidas iniciais no Firestore

## Abrir
1. Instale o Android Studio em um computador.
2. Extraia o ZIP e abra a pasta `OrbitSocialAndroid`.
3. Use JDK 17 e aceite a sincronização do Gradle.
4. Para testar sem backend, execute no emulador/celular. O feed de demonstração e publicações locais funcionam sem Firebase.

## Conectar Firebase (necessário para dados online)
1. Crie um projeto em https://console.firebase.google.com/
2. Adicione um app Android com package `com.orbitsocial.app`.
3. Baixe `google-services.json` e coloque em `app/google-services.json`.
4. No Firebase Authentication, habilite Email/Password.
5. Crie o Firestore Database.
6. Publique regras de segurança que exijam autenticação antes de permitir criar/alterar dados.
7. Ative Firebase Storage quando implementar upload de imagens.

> Não coloque chaves privadas ou credenciais administrativas no aplicativo. A validação de permissões e assinaturas deve ocorrer no servidor.

## Próximas etapas para uma versão pública
- Cadastro/login e recuperação de senha
- Upload de fotos e vídeos no Firebase Storage
- Comentários, seguidores e chat em tempo real
- Moderação, denúncias, bloqueios e privacidade
- Regras Firestore/Storage testadas
- Google Play Billing com validação de recibos no backend para Orbit Pro
- Política de privacidade, termos e exclusão de conta

## Observação
Este é um starter/protótipo, não um APK pronto para publicar. O backend exige configuração Firebase do proprietário. A tela PRO é apenas visual e não cobra nem concede assinatura real.
